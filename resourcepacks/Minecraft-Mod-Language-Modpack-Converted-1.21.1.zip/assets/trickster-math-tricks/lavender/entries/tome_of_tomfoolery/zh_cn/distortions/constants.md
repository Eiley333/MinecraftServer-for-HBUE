```json
{
  "title": "常量",
  "icon": "minecraft:bedrock",
  "category": "trickster-math-tricks:math-tricks"
}
```

此处记有本附属添加的各类常量。

;;;;;

<|pattern@trickster:templates|pattern=6\,0\,2\,8\,5,title=圆周之修订|>

{gray}（抄绘图案）{}

---

将符记换为数“π”。

;;;;;

<|pattern@trickster:templates|pattern=3\,4\,8\,7\,6\,3,title=四元数之修订|>

{gray}（抄绘图案）{}

---

将符记换为单位四元数。