```json
{
  "title": "LISP把戏秘典"
}
```

用LISP来编写和修改戏法师的法术！