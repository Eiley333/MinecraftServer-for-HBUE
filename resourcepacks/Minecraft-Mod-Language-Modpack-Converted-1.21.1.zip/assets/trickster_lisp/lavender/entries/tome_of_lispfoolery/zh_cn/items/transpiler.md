```json
{
  "title": "法术-LISP转译器",
  "icon": "trickster_lisp:transpiler",
  "category": "trickster_lisp:items",
  "associated_items": [
    "trickster_lisp:transpiler"
  ]
}
```

本模组的主要物品。

<recipe;trickster_lisp:transpiler>

右击即可打开[转译器界面](^trickster_lisp:transpiling/interface)，可在其中来回转换法术和类LISP代码。

;;;;;

转译器的详细用途介绍见[此](^trickster_lisp:transpiling)。


转译器中编写的代码会存储在物品中。


可以用转译器读取转译器。