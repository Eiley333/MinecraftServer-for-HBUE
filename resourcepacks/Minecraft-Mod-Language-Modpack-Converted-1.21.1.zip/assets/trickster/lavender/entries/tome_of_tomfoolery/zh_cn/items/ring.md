```json
{
  "title": "宏戒指",
  "icon": "trickster:macro_ring",
  "category": "trickster:items",
  "ordinal": 50
}
```

普通的金戒指，用于承载[宏](^trickster:concepts/macro)。

<recipe;trickster:macro_ring>
