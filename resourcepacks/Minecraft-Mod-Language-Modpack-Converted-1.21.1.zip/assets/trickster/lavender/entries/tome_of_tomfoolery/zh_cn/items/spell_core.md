```json
{
  "title": "法术核心",
  "icon": "trickster:spell_core",
  "category": "trickster:items",
  "ordinal": 110
}
```

法术核心可以插入[模块式法术组构台](^trickster:items/modular_spell_construct)，并在其中以玩家的75%速度运行抄入的法术。

;;;;;

为制造一个法术核心，必须使用一枚紫水晶的碎片作为*通路*，一颗末地的珍珠作为*心脏*，一缕金线作为*意识*，一圈皮革环作为*守卫*。

<recipe;trickster:spell_core>