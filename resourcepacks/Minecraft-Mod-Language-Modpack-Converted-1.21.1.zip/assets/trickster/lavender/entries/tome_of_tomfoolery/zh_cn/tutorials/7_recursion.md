```json
{
  "title": "6. 递归",
  "icon": "minecraft:paper",
  "ordinal": 5,
  "category": "trickster:tutorials"
}
```

即将到来！
