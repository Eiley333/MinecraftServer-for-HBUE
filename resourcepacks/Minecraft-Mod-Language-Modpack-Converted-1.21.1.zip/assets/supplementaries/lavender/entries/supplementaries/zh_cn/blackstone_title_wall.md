```json
{
  "title": "黑石瓦墙",
  "icon": "supplementaries:blackstone_tile_wall",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/walls",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:blackstone_tile_wall"
  ]
}
```

&spotlight(supplementaries:blackstone_tile_wall)
**黑石瓦墙**是[黑石瓦](^supplementaries:blackstone_tiles)的[墙](^minecraft:tag/walls)变种。

;;;;;

&title(合成)
<recipe;supplementaries:blackstone_tile_wall>
<recipe;supplementaries:stonecutting/blackstone_tile_wall_from_bricks>
