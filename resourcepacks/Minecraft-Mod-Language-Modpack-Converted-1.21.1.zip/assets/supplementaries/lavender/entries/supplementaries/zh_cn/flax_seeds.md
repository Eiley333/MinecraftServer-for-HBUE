```json
{
  "title": "亚麻种子",
  "icon": "supplementaries:flax_seeds",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/natural_blocks"
  ],
  "associated_items": [
    "supplementaries:flax_seeds"
  ]
}
```

&spotlight(supplementaries:flax_seeds)
**亚麻种子**是[亚麻](^supplementaries:flax)的种子，可作为稀有物品出现于箱子中（最常见的位置是前哨站），可由流浪商人出售，也可从[野生亚麻](^supplementaries:wild_flax)处获取。
