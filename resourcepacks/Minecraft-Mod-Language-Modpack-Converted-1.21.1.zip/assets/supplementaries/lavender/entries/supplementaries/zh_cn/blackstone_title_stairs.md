```json
{
  "title": "黑石瓦楼梯",
  "icon": "supplementaries:blackstone_tile_stairs",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/stairs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:blackstone_tile_stairs"
  ]
}
```

&spotlight(supplementaries:blackstone_tile_stairs)
**黑石瓦楼梯**是[黑石瓦](^supplementaries:blackstone_tiles)的[楼梯](^minecraft:tag/stairs)变种。

;;;;;

&title(合成)
<recipe;supplementaries:blackstone_tile_stairs>
<recipe;supplementaries:stonecutting/blackstone_tile_stairs_from_bricks>
