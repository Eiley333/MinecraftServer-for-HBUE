```json
{
  "title": "炮弹",
  "icon": "supplementaries:cannonball",
  "categories": [
    "knowlogy:entities",
    "minecraft:items",
    "minecraft:group/combat"
  ],
  "associated_items": [
    "supplementaries:cannonball"
  ]
}
```

&spotlight(supplementaries:cannonball)
**炮弹**是[大炮](^supplementaries:cannon)专属的弹射物。

;;;;;

&title(合成)
<recipe;supplementaries:cannonball>

;;;;;

&title(用途)
以较缓角度碰撞时会反弹。


能与所有实体产生机械交互，并将炮弹具有的部分能量转移出去，转移量由质量（判定箱）决定。
炮弹自身也在此列，试试看让两颗炮弹互撞吧！

;;;;;

&title(破坏方块)
会根据其动能水平摧毁所撞击的方块。


每次破坏方块都会减少其拥有的能量（速度），减少的量与方块硬度成正比。
