```json
{
  "title": "肥皂块",
  "icon": "supplementaries:soap_block",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:soap_block"
  ]
}
```

&spotlight(supplementaries:soap_block)
**肥皂块**能让其上方的实体“滑动”。

<block;supplementaries:soap_block>

;;;;;

&title(合成)
<recipe;supplementaries:soap_block>

;;;;;

&title(放置)
将肥皂块放置在湿海绵旁边，再在湿海绵旁边放上风箱，鼓风就可从湿海绵处吹出肥皂泡粒子。
