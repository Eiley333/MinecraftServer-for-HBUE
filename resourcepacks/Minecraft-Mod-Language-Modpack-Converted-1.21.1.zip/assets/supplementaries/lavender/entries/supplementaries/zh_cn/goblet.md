```json
{
  "title": "酒杯",
  "icon": "supplementaries:goblet",
  "categories": [
    "minecraft:blocks",
    "minecraft:group/functional_blocks"
  ],
  "associated_items": [
    "supplementaries:goblet"
  ]
}
```

&spotlight(supplementaries:goblet)
**酒杯**能盛装并展示任意液体。

;;;;;

&title(合成)
<recipe;supplementaries:goblet>

;;;;;

&title(用途)
有效的液体包括普通流体、药水、[蜂蜜](^minecraft:honey_bottle)、奶等，支持许多模组。如果玻璃瓶或碗能装某样东西，那它很有可能也算是能装入酒杯的液体。


若酒杯中盛装有可饮用的液体，则直接点击酒杯就可饮用。

;;;;;

&title(红石)
能与红石比较器交互。
