```json
{
  "title": "灰烬砖楼梯",
  "icon": "supplementaries:ash_bricks_stairs",
  "categories": [
    "minecraft:blocks",
    "minecraft:tag/stairs",
    "minecraft:group/building_blocks"
  ],
  "associated_items": [
    "supplementaries:ash_bricks_stairs"
  ]
}
```

&spotlight(supplementaries:ash_bricks_stairs)
**灰烬砖楼梯**是[灰烬砖块](^supplementaries:ash_bricks)的[楼梯](^minecraft:tag/stairs)变种。

;;;;;

&title(合成)
<recipe;supplementaries:ash_brick_stairs>
<recipe;supplementaries:stonecutting/ash_brick_stairs_from_bricks>
