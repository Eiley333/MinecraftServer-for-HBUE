```json
{
  "title": "糖果",
  "icon": "supplementaries:candy",
  "categories": [
    "minecraft:items",
    "minecraft:group/food_and_drinks"
  ],
  "associated_items": [
    "supplementaries:candy"
  ]
}
```

&spotlight(supplementaries:candy)
**糖果**是简单的食物物品，食用速度快，能恢复半格饥饿值。
吃太多可能会有副作用。

;;;;;

&title(合成)
<recipe;supplementaries:candy>
